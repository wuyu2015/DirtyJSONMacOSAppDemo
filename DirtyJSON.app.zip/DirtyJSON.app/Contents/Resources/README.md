# DirtyJSONMacOSAppDemo

A simple macOS demo app showcasing the usage of the [DirtyJSONSwift](https://github.com/wuyu2015/DirtyJSONSwift) and [StupidNSWindow](https://github.com/wuyu2015/StupidNSWindow) packages.

一个简单的 macOS 演示应用程序，展示了 [DirtyJSONSwift](https://github.com/wuyu2015/DirtyJSONSwift) 和 [StupidNSWindow](https://github.com/wuyu2015/StupidNSWindow) 包的使用方法。

<img src="https://raw.githubusercontent.com/wuyu2015/DirtyJSONMacOSAppDemo/main/screenshot.png" alt="screenshot" style="zoom:100%;" />
